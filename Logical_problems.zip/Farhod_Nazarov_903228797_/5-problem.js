/*
	Berilgan string orasida bitta katta xarf bor so'zni o'sha xarfdan boshlab tartiblaydiga 
	fubction yozing?

	For example:
	string = "kumAsslomu alay"
	correction_sentence(string) // result: Asslomu alaykum
*/
let letter = "kumassalomu Alay"
function correction_sentence(let){
	let newstr = ''
	let str = ''
	for(let i = 0; i<let.length; i++){
		if(let[i]==let[i].toUpperCase()){
			for (let j = i; j<let.length; j++ ){
				newstr+=let[j]
			}
			break
		}
		str+=let[i]
	}
	let result = newstr+str 
	return result
}
console.log(correction_sentence(letter))
