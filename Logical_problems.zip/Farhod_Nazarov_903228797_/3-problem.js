/*
	ichma ich joylashgan listlar berilgan har bir list elementining ichida xoxlagancha list
	bo'lishi mumkin shu listlarni sanab beradigan function yozing?

	For example:
	list=[1,2,[4,5,[5,[2,3],6]],[1,2]]
	count(list) // result:5
*/
let lst = [1,2,[4,5,[5,[2,3],6]],[1,2]]
let result = 1
function count(list){
	list.forEach(j=>{
		if(typeof j == 'object'){
			result++
			count(j)
		}
    })
    return result

}
console.log(count(lst))