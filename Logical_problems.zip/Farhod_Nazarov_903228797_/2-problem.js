/*
	Ixtiyoriy string ma'lumotni unli harflar bo'yicha bo'lib beradigan
	function yozing

	For example: 
	strring = 'patrikaleus' 
	function str(string)// result:['a','atri','i','ika','a','ale','e','eu','u']
*/

function volwel_words(str) {
	let result = []
	let string = ''
	for ( let i = 0; i<str.length; i++) {
		if ( str[i] == 'a' || str[i] == 'o' || str[i] == 'i' || str[i] == 'u' || str[i] == 'e'){
			string +=str[i]
			result.push(string)
			if((string[string.length-1] == 'a' || string[string.length-1] == 'o' || string[string.length-1] == 'i' || string[string.length-1] == 'u' || string[string.length-1] == 'e')
				&&(string[string.length-2] == 'a' || string[string.length-2] == 'o' || string[string.length-2] == 'i' || string[string.length-2] == 'u' || string[string.length-2] == 'e')){
				result.push(string[string.length-1])
			}
			string=string[0]
			continue
		}
		if(i!=0 && result.length!=0){
			string +=str[i]
		}
	}
	return result
}
let word = 'albaotross'
console.log(volwel_words(word))
