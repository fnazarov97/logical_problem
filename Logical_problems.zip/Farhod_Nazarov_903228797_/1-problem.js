/*
	ikkita list berilgan faqat natural sonlardan iborat ularni birlashtirganda taribli yoki 
	tartibli emasligini tekshiruvchi function yozing?
	for example: 
	list1=[1,4,3,5,2];
	list2=[1,8,3,6,2];
	isSorted(list1,list2)// result: false

	list1=[1,4,3,5,2];
	list2=[8,7,6,9];
	isSorted(list1,list2)// result: true

*/
function chek_sequence(lst1,lst2){
	let con = array1.concat(array2)
	let sorted = con.sort( (a,b) => a-b )
	let check = 1
	for( let i=0; i<sorted.length; i++ ) {
		if(sorted[i]+1 == sorted[i+1]) {
			check++
		}
	}
	return check === sorted.length
}

let array1 = [ 2,4,5,7,9 ]
let array2 = [ 3,1,6,8 ]
console.log(chek_sequence(array1,array2))
 