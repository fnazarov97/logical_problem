/*
	Birinchi parametrida ko'rsatilgan listni ikkinchi parametridagi son bo'yicha listlarga joylab o'sha 
	listlarni bitta listga append qilib beradigan function yozing?

	For example:
	list = [1,2,3,4,'hello',2,6,'bye']
	number = 2
	group_by_ekub(list,number) // result: [[1,2],[3,4],['hello',2],[6,'bye']]
*/
function group_by_ekub(lst,number){
	let a=0
	let arr=[]
	let result=[]
	if(lst.length>=number){
		lst.forEach(j=>{
			arr.push(j)
			if(arr.length==number){
				result.push(arr)
				arr=[]
			}
		})
	}else{
		result.push(lst)
	}
	return result
}
let l = [1,2,'hello',4,5,6,8,9]
let num = 4
console.log(group_by_ekub(l,num))

